package com.example.flat;

public enum CoordinateTypes {
    GRAUS,
    GRAUS_MINUTOS,
    GRAUS_MINUTOS_SEGUNDOS
}
