package com.example.flat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.button_gnss_view).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Inicia a GnssViewActivity
                startActivity(new Intent(MainActivity.this, GNSSActivity.class));
            }
        });

        findViewById(R.id.button_activity_2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Definir o Intent para Atividade 2
            }
        });

        findViewById(R.id.button_activity_3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Definir o Intent para Atividade 3
            }
        });
    }
}
