package com.example.flat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class CompassView extends View {

    private float mDegree = 0;
    private Paint backgroundPaint = new Paint();
    private Paint borderPaint = new Paint();
    private Paint textPaint = new Paint();
    private Paint needlePaint = new Paint();
    private int compassRadius = 120; // Raio da bússola

    public CompassView(Context context) {
        super(context);
        init(null, 0);
    }

    public CompassView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs, 0);
    }

    public CompassView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(attrs, defStyle);
    }

    private void init(AttributeSet attrs, int defStyle) {
        backgroundPaint.setColor(Color.BLACK); // Cor de fundo preta
        backgroundPaint.setAntiAlias(true);

        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(8); // Espessura da borda
        borderPaint.setColor(Color.WHITE); // Cor da borda da bússola

        textPaint.setTextSize(22);
        textPaint.setFakeBoldText(true);
        textPaint.setColor(Color.WHITE);
        textPaint.setAntiAlias(true);

        needlePaint.setStrokeWidth(12); // Tamanho da agulha
        needlePaint.setAntiAlias(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Plano de fundo
        canvas.drawRect(0, 0, getWidth(), getHeight(), backgroundPaint);

        float centerX = getWidth() / 2;
        float centerY = getHeight() / 2;

        // Desenhar o círculo branco ao redor da bússola
        canvas.drawCircle(centerX, centerY, compassRadius - 20, borderPaint); // Círculo branco menor

        // Desenhar direções
        drawCompassDirections(canvas, centerX, centerY);
        // Desenhar agulha
        drawNeedle(canvas, centerX, centerY);

        // Mostrar o ângulo atual (ajustado para cima e para a direita)
        canvas.drawText(mDegree + "°", 70, 30, textPaint); // Novas coordenadas
    }

    // Desenha as direções Norte, Sul, Leste e Oeste
    private void drawCompassDirections(Canvas canvas, float centerX, float centerY) {
        textPaint.setColor(Color.WHITE);
        textPaint.setTextAlign(Paint.Align.CENTER);

        // Norte
        canvas.drawText("N", centerX, centerY - compassRadius + 50, textPaint);
        // Sul
        canvas.drawText("S", centerX, centerY + compassRadius - 30, textPaint);
        // Leste
        canvas.drawText("E", centerX + compassRadius - 50, centerY + 10, textPaint);
        // Oeste
        canvas.drawText("W", centerX - compassRadius + 50, centerY + 10, textPaint);
    }

    // Desenha a agulha da bússola
    private void drawNeedle(Canvas canvas, float centerX, float centerY) {
        // Agulha apontando para o norte (vermelha)
        needlePaint.setColor(Color.RED);
        canvas.save(); // Salva o estado do canvas
        canvas.rotate(mDegree, centerX, centerY); // Rotaciona o canvas

        // A agulha vermelha vai do centro até o topo da bússola
        canvas.drawLine(centerX, centerY, centerX, centerY - compassRadius + 40, needlePaint);

        // Parte oposta da agulha (azul)
        needlePaint.setColor(Color.BLUE);
        canvas.drawLine(centerX, centerY, centerX, centerY + compassRadius - 40, needlePaint);

        // Restaura o estado do canvas
        canvas.restore();

        // Círculo central
        needlePaint.setStyle(Paint.Style.FILL);
        needlePaint.setColor(Color.WHITE);
        canvas.drawCircle(centerX, centerY, 15, needlePaint); // Ajuste o tamanho do círculo central
    }

    public void setDegree(float degree) {
        this.mDegree = degree;
        invalidate();
    }
}